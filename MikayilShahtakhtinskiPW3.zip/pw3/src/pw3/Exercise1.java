package pw3;
import java.util.Arrays;
interface StringFilter {
	
	String filter(String s);
}
class UpperCaseStringFilter implements StringFilter{
	public String filter(String s) {
		return s.toUpperCase();
	}
}
class LowerCaseStringFilter implements StringFilter{
	public String filter(String s) {
		return s.toLowerCase();
	}
}
class PrefixStringFilter implements StringFilter{
	public int characters;
	public PrefixStringFilter(int characters) {
		this.characters = characters;
	}
	public String filter(String s) {
		return s.substring(0,characters);
	}
}
class SuffixStringFilter implements StringFilter{
	public int characters;
	public SuffixStringFilter(int characters) {	
		this.characters = characters;
	}
	
	public String filter(String s) {
		return s.substring(s.length()-characters);
	}
	
}
class CompositeStringFilter implements StringFilter{
	StringFilter[] filters;
	public CompositeStringFilter(StringFilter[] filters) {
		this.filters = filters;
	}
	public String filter(String s) {
		String d ="";
		for(int i = 0; i < filters.length;i++) {
			System.out.println(filters[i].filter(s));
		}
		return d;
	}
}
public class Exercise1 {
	public static String[] filter(String[] string, StringFilter filter) {
		int len = string.length;
		String[] arr = new String[len];
		for(int i = 0 ; i < len ; i ++) {
			arr[i] = filter.filter(string[i]);
		}
		return arr;
		
	}
	public static void main(String[] args) {
		System.out.print("Taking String (Mika). ");
		System.out.println("Let's take firs 3 char");
		PrefixStringFilter p1 = new PrefixStringFilter(3);
		System.out.println("Answer is: "+p1.filter("Mika"));
		System.out.println("Let's take last 2 char");
		SuffixStringFilter p2 = new SuffixStringFilter(2);
		System.out.println("Answer is: "+p2.filter("Mika"));
		System.out.println("Let's make char to UpperCase ");
		UpperCaseStringFilter p3 = new UpperCaseStringFilter();
		System.out.println("Answer is: "+p3.filter("mika"));
		System.out.println("Let's make char to UpperCase ");
		LowerCaseStringFilter p4 = new LowerCaseStringFilter();
		System.out.println("Answer is: "+p4.filter("MIKA"));
		System.out.println("Using arrays of lower String with UpperCase filter in the static method:");
		String[] string = {"Mika", "aydin", "papa", "mAma"};
		String[] string2 = {"MIKA", "AYDIN", "PaPa", "MAma"};
		StringFilter filter = new UpperCaseStringFilter();
		System.out.println(Arrays.toString(filter(string,filter)));
		System.out.println("Using arrays of upper Strings with LowerCase filter in the static method:");
		StringFilter filter1 = new LowerCaseStringFilter();
		System.out.println(Arrays.toString(filter(string2,filter1)));
		StringFilter[] filters = {new UpperCaseStringFilter(), new LowerCaseStringFilter(), new PrefixStringFilter(3), new SuffixStringFilter(2)};
		System.out.println("Using all filters in string (Aydin) (Upper,Lower,first(3),last(2))");
		CompositeStringFilter p5 = new CompositeStringFilter(filters);
		System.out.println(p5.filter("Aydin"));
	}
}
