package pw3;

interface ArithmeticExpression {
	public String asString();
	public float asValue();
}

class Variable implements ArithmeticExpression{
	public float num;
	public String s;

	public float getNum() {
		return num;
	}
	public void set(float num) {
		this.num = num;
	}
	public String getS() {
		return s;
	}
	public void setS(String s) {
		this.s = s;
	}
	public Variable(String s, float num) {
		this.s = s;
		this.num = num;
	}
	public String asString() {
		return s;
	}
	public float asValue() {
		return this.num;
	}	
}

class Sum implements ArithmeticExpression{
	ArithmeticExpression op1;
	ArithmeticExpression op2;
	
	
	public Sum(ArithmeticExpression op1, ArithmeticExpression op2) {
		this.op1 = op1;
		this.op2 = op2;
	}		
	
	public float asValue() {
		return this.op1.asValue()+this.op2.asValue();
	}
	@Override
	public String asString() {
		String s = "("+this.op1.asString() + "+" + this.op2.asString()+")";
		return s;	
	}
	
}
class Product implements ArithmeticExpression {
	ArithmeticExpression op1;
	ArithmeticExpression op2;

	public Product(ArithmeticExpression op1, ArithmeticExpression op2) {
		this.op1 = op1;
		this.op2 = op2;
	}

	@Override
	public String asString() {
		return "("+this.op1.asString()+"*"+this.op2.asString()+")";
	}

	@Override
	public float asValue() {
		return this.op1.asValue()*this.op2.asValue();
	}
}

class Division implements ArithmeticExpression {
	ArithmeticExpression op1;
	ArithmeticExpression op2;

	public Division(ArithmeticExpression op1, ArithmeticExpression op2) {
		this.op1 = op1;
		this.op2 = op2;
	}

	@Override
	public String asString() {
		return "("+this.op1.asString()+"/"+this.op2.asString()+")";
	}

	@Override
	public float asValue() {
		return this.op1.asValue()/this.op2.asValue();
	}
	
}
class Subtraction implements ArithmeticExpression {
	ArithmeticExpression op1;
	ArithmeticExpression op2;

	public Subtraction(ArithmeticExpression op1, ArithmeticExpression op2) {
		this.op1 = op1;
		this.op2 = op2;
	}

	@Override
	public String asString() {
		return "("+this.op1.asString()+"-"+this.op2.asString()+")";
	}

	@Override
	public float asValue() {
		return this.op1.asValue()-this.op2.asValue();
	}
}
public class Exercise2 {

	public static void main(String[] args) {
		Variable x = new Variable("x", 2.5f);
		Variable y = new Variable("y", 4);
		ArithmeticExpression exp = new Sum(x, new Product(y, new Sum(x, y)));
		System.out.println(exp.asString());
		System.out.println(exp.asValue());
		x.set(5);
		System.out.println(exp.asValue());
		
		ArithmeticExpression exp1 = new Division(x, y);
		System.out.println("Let's check divison");
		System.out.println(exp1.asString());
		System.out.println("Answer is : "+exp1.asValue());
		
		ArithmeticExpression exp2 = new Subtraction(x, y);
		System.out.println("Let's check subtraction");
		System.out.println(exp2.asString());
		System.out.println("Answer is : "+exp2.asValue());		
	}

}
