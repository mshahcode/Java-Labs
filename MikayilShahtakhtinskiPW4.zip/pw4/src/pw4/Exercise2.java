package pw4;

class MyArray<E>{
	private Object[] objects;
	private int maxcapacity;
	private int size;
	public MyArray(int maxcapacity) {
		this.objects = new Object[maxcapacity];
		this.maxcapacity = maxcapacity;
		size = 0;
	}
	public int size() {
		return this.size;
	}
	public boolean isEmpty() {
		return size==0;
	}
	public void add(E e) {		
		if(size>=maxcapacity) {
			return;	
		}
		this.objects[size] = e;
		this.size++;
	}
	
	public Object get(int i) {
		if(i<0 || i > this.size || i >=this.maxcapacity) {
			return null;
		}
		return this.objects[i];
		
	}
	public void remove(int index) {
		if(index<0 || index >= this.maxcapacity || index > this.size) {
			return;
		}
		for(int i = index; i<this.size-1;i ++) {
			objects[i] = objects[i+1];
		}
		size--;
		
		
	}
	public String toString() {
		String s = "";
		for(int i = 0 ; i < size ; i++) {
			s+= this.objects[i].toString()+" ";
		}
		return s;
	}
	
}
public class Exercise2 {

	public static void main(String[] args) {
		System.out.println("Setting max capacity of array to: 4");
		MyArray<Integer> myarr = new MyArray<Integer>(4);
		System.out.println("Arrays is empty or not: "+myarr.isEmpty());
		System.out.println("Adding 1,2,3,4 to our array");
		myarr.add(1);
		myarr.add(2);
		myarr.add(3);
		myarr.add(4);
		System.out.print("The number of elements is array is :");
		System.out.println(myarr.size());
		System.out.println(myarr.toString());
		System.out.println("Arrays is empty or not: "+myarr.isEmpty());
		System.out.print("Getting element in 2 index: ");
		System.out.println(myarr.get(2));
		System.out.println("Removing element at index 2: ");
		myarr.remove(2);
		System.out.println("Arrays now is : ");
		System.out.println(myarr.toString());
		System.out.println("Arrays is empty or not: "+myarr.isEmpty());
		System.out.print("The number of elements is array is :");
		System.out.println(myarr.size());

		
	}

}
