package Exercise1;


class MaxCapacityException extends Exception{
	private int capacity;
	public MaxCapacityException(int capacity) {
		this.capacity = capacity;
	}
	@Override
	public String getMessage() {
		return "Can't exceed max capacity";
	}
}
class ElementNotFoundException extends Exception {
	private Object o;
	public ElementNotFoundException(Object o ) {
		this.o = o;
	}
	public String getMessage() {
		return "Element at index"+o+" is not found";
	}
}
class InvalidIndexException extends Exception {
	private int index;
	public InvalidIndexException(int index) {
		this.index = index;
	}
	@Override
	public String getMessage() {
		return "The index is invalid!";
	}
}
class MyArray<E>{
	public Object[] objects;
	public int maxcapacity;
	public int size;
	public MyArray(int maxcapacity) {
		this.objects = new Object[maxcapacity];
		this.maxcapacity = maxcapacity;
		size = 0;
	}
	public int size() {
		return this.size;
	}
	public boolean isEmpty() {
		return size==0;
	}
	public void add(E e) throws MaxCapacityException{		
		if(size>=maxcapacity) {
			throw new MaxCapacityException(maxcapacity);	
		}
		this.objects[size] = e;
		this.size++;
	}
	
	public Object get(int i) throws InvalidIndexException {
		if(i<0 || i > this.size || i >=this.maxcapacity) {
			throw new InvalidIndexException(i);
		}
		return this.objects[i];
		
	}
	public void remove(int index) {
		if(index<0 || index >= this.maxcapacity || index > this.size) {
			return;
		}
		for(int i = index; i<this.size-1;i ++) {
			objects[i] = objects[i+1];
		}
		size--;
	}
	public int find(E e) throws ElementNotFoundException {
		for(int i = 0 ; i < this.size; i ++ ) {
			if(e.equals(this.objects[i])) {
				return i;
			}
		}
		throw new ElementNotFoundException(e);
	}
	public String toString() {
		String s = "";
		for(int i = 0 ; i < size ; i++) {
			s+= this.objects[i].toString()+" ";
		}
		return s;
	}
	
}
public class Exercise1 {

	public static void main(String[] args) {
		System.out.println("Setting max capacity of array to: 4");
		MyArray<Integer> myarr = new MyArray<Integer>(4);
		System.out.println("Arrays is empty or not: "+myarr.isEmpty());
		System.out.println("Adding 1,2,3,4 to our array");
		try {
			myarr.add(1);
			myarr.add(2);
			myarr.add(3);
			myarr.add(4);	
		} catch(MaxCapacityException e) {
			e.printStackTrace();
			
		}
		
		System.out.print("The number of elements is array is :");
		System.out.println(myarr.size());
		System.out.println(myarr.toString());
		System.out.println("Arrays is empty or not: "+myarr.isEmpty());
		System.out.print("Getting element in 2 index: ");
		try {
			System.out.println(myarr.get(2));

		} catch (InvalidIndexException e) {
			e.printStackTrace();
		}
		System.out.println("Removing element at index 2: ");
		myarr.remove(2);
		System.out.println("Arrays now is : ");
		System.out.println(myarr.toString());
		System.out.println("Arrays is empty or not: "+myarr.isEmpty());
		System.out.print("The number of elements is array is :");
		System.out.println(myarr.size());
		try {
			System.out.println("Find index of  1 element: "+myarr.find(1));
		} catch(ElementNotFoundException e) {
			e.printStackTrace();
		}
		

		
	}

}
