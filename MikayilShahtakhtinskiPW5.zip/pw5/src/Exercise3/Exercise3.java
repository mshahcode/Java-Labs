package Exercise3;
import java.util.Arrays;
class MaxCapacityException extends Exception{
	private int capacity;
	public MaxCapacityException(int capacity) {
		this.capacity = capacity;
	}
	@Override
	public String getMessage() {
		return "Can't exceed max capacity";
	}
}
class EmptyStackException extends Exception{
	private int top;
	public EmptyStackException(int top) {
		this.top = top;
	}
	@Override
	public String getMessage() {
		return "The stack is empty";
	}
}
class MyStack<E>{
    private int top;
    private int capacity;
    private Object arr[];
    public MyStack(int capacity) {
    	this.arr = new Object[capacity];
    	this.capacity = capacity;
    	this.top=-1;
    }
    public int getCapacity() {
    	return this.capacity;
    }
    public void push(E e) throws MaxCapacityException{
    	if(top>=capacity) {
    		throw new MaxCapacityException(capacity);
    	}
		this.arr[++top] = e;
    }
    public Object peek() throws EmptyStackException{
    	if(isEmpty()) {
    		throw new EmptyStackException(top);
    	}
        return arr[top];
    }
    public Object pop() throws EmptyStackException{
    	if(isEmpty()) {
    		throw new EmptyStackException(top);
    	}
        return arr[top--];
    }
    public boolean isEmpty(){
        return top==-1;
    }
    public String toString() {
    	return "Stack is: "+Arrays.toString(arr)+",capacity is: "+this.capacity+",current top is: "+this.top;
    }  
}
class ParenthesisMatching{
	private String s;
	private MyStack<Character> mystack;
	public String getS() {
		return s;
	}
	public void setS(String s) {
		this.s = s;
	}
	public MyStack<Character> getMystack() {
		return mystack;
	}
	public void setMystack(MyStack<Character> mystack) {
		this.mystack = mystack;
	}
	public ParenthesisMatching(String s) {
		this.s= s;
		mystack = new MyStack<Character>(s.length());
	}
	private static boolean bracketsAreMatching(char c1, char c2) {
		if(c1 == '(' && c2 == ')' ) {
			return true;
		}else {
			return false;
		}
	}
	public boolean parse() {
		char[] newchar = this.s.toCharArray();
		for(int i = 0 ; i < newchar.length;i++) {
			if(newchar[i] == '(') {
				try {
					mystack.push(newchar[i]);
				} catch (MaxCapacityException e) {
					e.printStackTrace();
				}
			}
			if(newchar[i] == ')') {
				if(mystack.isEmpty()) {
					return false;
				}
				char c = 0;
				try {
					c = (char) mystack.pop();
				} catch (EmptyStackException e) {
					e.printStackTrace();
				}
				if(!bracketsAreMatching(c, newchar[i])) {
					return false;
				}
			}
		}
		return this.mystack.isEmpty();
	}
}
public class Exercise3 {

	public static void main(String[] args) {
		System.out.println("Checking ((a+b)-(c+d))");
		ParenthesisMatching string  = new ParenthesisMatching("((a+b)-(c+d))");
		System.out.println(string.parse());
		string.setS("a+(b+(c+d))");
		System.out.println("Checking a+(b+(c+d))");
		System.out.println(string.parse());
		string.setS("((a+b)+c");
		System.out.println("Checking ((a+b)+c");
		System.out.println(string.parse());
		string.setS("((a+b)+c");
		System.out.println("Checking ((a+b)+c");
		System.out.println(string.parse());
		string.setS("((a+b)+c))");
		System.out.println("Checking ((a+b)+c))");
		System.out.println(string.parse());
		string.setS(")a+b(");
		System.out.println("Checking )a+b(");
		System.out.println(string.parse());	
	}

}
