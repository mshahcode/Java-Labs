package pw6;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
class CSVReader {
	private String name;
	private ArrayList<String[]> entries= new ArrayList<String[]>();;
	
	public CSVReader(String name) {
		this.name=name;
	}
	
	public void importData(){
		try {
			BufferedReader reader = new BufferedReader(new FileReader(this.name));
			String line;
			String[] temp;
			while((line = reader.readLine())!=null) {
				temp = line.split(",");
			    getEntries().add(temp);
			}
			reader.close();
		} catch (FileNotFoundException e2) {
			e2.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public int getNumberOfEntries() {
		return getEntries().size();
	}
	
	public ArrayList<String> getEntry(int i){
		ArrayList<String> entry= new ArrayList<String>(Arrays.asList(getEntries().get(i)));
		return entry;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public ArrayList<String[]> getEntries() {
		return entries;
	}
	
	public void setEntries(ArrayList<String[]> entries) {
		this.entries = entries;
	}
}
public class Exercise1 {

	public static void main(String[] args) {
		CSVReader csv = new CSVReader("exported(entries).txt");
		
		csv.importData();
		
		System.out.println("Number of entries is : "+ csv.getNumberOfEntries());
		
		System.out.println("The first entry is : " + csv.getEntry(0));
		
		System.out.println("The third entry is : " + csv.getEntry(2));

		System.out.println("Lest get 2 entry: "+ csv.getEntry(1));
	}

}
