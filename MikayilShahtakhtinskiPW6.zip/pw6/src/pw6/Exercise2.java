package pw6;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Arrays;
class SaveRestoreObjFromFile{
	public static void saveToFile(String outputFile, Object object) throws IOException {
		ObjectOutputStream output = new ObjectOutputStream(new FileOutputStream(outputFile));
		output.writeObject(object);
		System.out.println("Succesfully exported");
		output.close();
	}
	public static  Object restoreFromFile(String inputFile) throws IOException, ClassNotFoundException {
		ObjectInputStream input = new ObjectInputStream(new FileInputStream(inputFile));
		System.out.println("Succesfully imported");
		Object x = input.readObject();
		input.close();
		return x;
	}

}
public class Exercise2 {
	@SuppressWarnings({ "unchecked", "static-access" })
	public static void main(String[] args) throws IOException, ClassNotFoundException {
		SaveRestoreObjFromFile file1 = new SaveRestoreObjFromFile();
		CSVReader csv = new CSVReader("exported(entries).txt");
		csv.importData();
		file1.saveToFile("imported.ser", csv.getEntries());
		ArrayList<String[]> arr = (ArrayList<String[]>) file1.restoreFromFile("imported.ser");
		
		System.out.println("Lets check imported.ser (entries from exported) , by iterating ArrayList");
		for(String[] array : arr) {
		    System.out.println(Arrays.toString(array));
		}
	}
}
