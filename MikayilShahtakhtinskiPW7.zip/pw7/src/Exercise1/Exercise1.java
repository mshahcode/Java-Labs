package Exercise1;
class Horse{
	private String name;
	private String color;
	private int year;
	public Horse(String name, String color, int year) {
		this.name = name;
		this.color = color;
		this.year = year;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
}
class Racehorse extends Horse{
	private int win;
	public Racehorse(String name, String color, int year,int win) {
		super(name, color, year);
		this.win = win;
	}
	public int getWin() {
		return win;
	}
	public void setWin(int win) {
		this.win = win;
	}
}
class Workhorse extends Horse{
	private int yearswork;
	public Workhorse(String name, String color, int year,int yearswork) {
		super(name, color, year);
		this.yearswork = yearswork;
	}
	public int getYearswork() {
		return yearswork;
	}
	public void setYearswork(int yearswork) {
		this.yearswork = yearswork;
	}
}
public class Exercise1 {

	public static void main(String[] args) {
		Racehorse race = new Racehorse("Mustang", "Black", 2017, 27);
		Workhorse work = new Workhorse("Slave", "White", 2010, 4);
		System.out.println(String.format("The name of racehorse is %s , color is %s, year of birth is %d, wins are : %d",race.getName(),race.getColor(),race.getYear(),race.getWin()));		
		System.out.println(String.format("The name of workhorse is %s , color is %s, year of birth is %d, hours of work are : %d",work.getName(),work.getColor(),work.getYear(),work.getYearswork()));
		System.out.println("Let's change the color of Slave ( workhorse) to Brown-Black");
		work.setColor("Brown-black");
		System.out.println(String.format("The name of workhorse is %s , color is %s, year of birth is %d, hours of work are : %d",work.getName(),work.getColor(),work.getYear(),work.getYearswork()));
		System.out.println("Changing the name of racehorse, which is Mustang to Ferrari");
		race.setName("Ferrari");
		System.out.println(String.format("The name of racehorse is %s , color is %s, year of birth is %d, wins are : %d",race.getName(),race.getColor(),race.getYear(),race.getWin()));		

		
	}

}
