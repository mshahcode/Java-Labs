package Exercise2;
class Poem{
	private String title;
	private int lines;
	public Poem(String title,int lines) {
		this.title = title;
		this.lines=lines;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public int getLines() {
		return lines;
	}
	public void setLines(int lines) {
		this.lines = lines;
	}
	
}
class Couplet extends Poem{
	private final static int lines = 2;
	public Couplet(String title) {
		super(title, lines);
	}
}
class Limerick extends Poem{
	private final static int lines = 5;
	public Limerick(String title) {
		super(title,lines);
	}
}
class Haiku extends Poem{
	private final static int lines = 3;
	public Haiku(String title) {
		super(title,lines);
	}
}
public class Exercise2 {

	public static void main(String[] args) {
		Poem poem = new Poem("Mikail", 12);
		System.out.println(String.format("Just a poem : Title is %s and num of lines are %d", poem.getTitle(),poem.getLines()));
		Couplet couple = new Couplet("Great");
		System.out.println(String.format("Couplet: Title is %s and num of lines are %d", couple.getTitle(),couple.getLines()));
		Limerick limerick = new Limerick("Bad");
		System.out.println(String.format("Limerick : Title is %s and num of lines are %d", limerick.getTitle(),limerick.getLines()));
		Haiku haiku = new Haiku("Marvel");
		System.out.println(String.format("Haiku : Title is %s and num of lines are %d", haiku.getTitle(),haiku.getLines()));
		System.out.println("Let's change the name of title to Spider instead of Marvel and add one more line");
		haiku.setTitle("Spider");
		haiku.setLines(4);
		System.out.println(String.format("Haiku : Title is %s and num of lines are %d", haiku.getTitle(),haiku.getLines()));

		

	}

}
