package Exericse3;

import java.util.Arrays;

class Department{
	private String name;
	public Department(String name) {
		switch (name) {
		case "CS":
			this.name = "Computer Science";
			break;
		case "CHEM":
			this.name = "Chemistry";
			break;
		case "PHY":
			this.name = "Physics";
			break;
		default:
			System.out.println("Wrong name!");
		}
	}
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}	
}
class University{
	private String name;
	private String city;
	private Department[] departments;
	public University(String name, String city,Department[] departments) {
		this.name = name;
		this.city = city;
		this.departments = departments;
	}
	public Department[] getDepartments() {
		return departments;
	}
	public void setDepartments(Department[] departments) {
		this.departments = departments;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String printUni() {
		String[] str = new String[departments.length];
		int i =0;
		for(i = 0;i< departments.length;i++) {
			str[i] = departments[i].getName();
		}
		return "University : "+name+", City : "+city+", Department :  "+Arrays.toString(str);
	}
}
class UniveristyCourse{
	private String coursename;
	private Department department;
	private int coursenum;
	private int numofcredit;
	
	public UniveristyCourse(String coursename, Department derpartment, int coursenum, int numofcredit) {
		this.coursename = coursename;
		this.department = derpartment;
		this.coursenum = coursenum;
		this.numofcredit = numofcredit;
	}
	
	public String getNameofuni() {
		return coursename;
	}

	public void setNameofuni(String coursename) {
		this.coursename = coursename;
	}

	public Department getDepartnemt() {
		return department;
	}

	public void setDepartnemt(Department departnemt) {
		this.department = departnemt;
	}

	public int getCoursenum() {
		return coursenum;
	}

	public void setCoursenum(int coursenum) {
		this.coursenum = coursenum;
	}

	public int getNumofcredit() {
		return numofcredit;
	}

	public void setNumofcredit(int numofcredit) {
		this.numofcredit = numofcredit;
	}

	public String toString(){
		return this.coursenum+" - "+this.coursename+" (department of "+ department.getName() +") / "+ this.numofcredit + " credits";
		
	}
}

public class Exercise3 {

	public static void main(String[] args) {
		Department departnemt = new Department("CS");
		UniveristyCourse un1 = new UniveristyCourse("Object Oriented Programming", departnemt, 308, 3);
		System.out.println(un1.toString());
		
		System.out.println("Now, let's check another methods and objects");
		
		Department department2 = new Department("CHEM");
		UniveristyCourse un2 = new UniveristyCourse("Reactions and Equilibrium", department2, 309, 6);
		System.out.println(un2.toString());
		
		Department department3 = new Department("PHY");
		UniveristyCourse un3 = new UniveristyCourse("Velocity and Acceleration", department3, 310, 2);
		System.out.println(un3.toString());
		
		System.out.println("Let's change the number of credits in course Velocity and Acceleration to 5");
		un3.setNumofcredit(5);
		System.out.println(un3.toString());
		
		System.out.println("Let's create a university UFAZ");
		Department[] departments = {departnemt, department2 , department3};
		University ufaz = new University("UFAZ","BAKU", departments);
		System.out.println(ufaz.printUni());

		
	}

}
