package Exericse4;
interface Runner{
	public void run();
}
class CoffeeMachine implements Runner{
	public void run() {
		System.out.println("Coffe Machine is running");
	}
}
class Athlete implements Runner{
	public void run() {
		System.out.println("Athlete is running");
	}
}
class PoliticalCandidate implements Runner{
	public void run() {
		System.out.println("The Political Candidate is running");
	}
}
public class Exercise4 {

	public static void main(String[] args) {
		Runner coffe = new CoffeeMachine();
		coffe.run();
		Runner athlet = new Athlete();
		athlet.run();
		Runner politic = new PoliticalCandidate();
		politic.run();
	}

}
