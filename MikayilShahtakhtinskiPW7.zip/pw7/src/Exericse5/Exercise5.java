package Exericse5;

class Subscription{
	private String name;
	private String address;
	private float rate;
	public Subscription(String name,String address) {
		this.name = name;
		this.address = address;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public float getRate() {
		return rate;
	}
	public void setRate(float rate) {
		this.rate = rate;
	}
	public String toString() {
		return "Subscriber [name: "+this.name + ",address= " + this.address +",rate= "+this.rate+"]";
	}
}
class PhysicalSubscription extends Subscription{
	public PhysicalSubscription(String name,String address) throws Exception {
		super(name,address);
		if(address.matches(".*\\d+.*")) {
			this.setRate(5);		
		}else {
			throw new Exception(address);
		}
	}
	public String toString() {
		return "Physical "+super.toString();
	}
}
class OnlineSubscription extends Subscription{
	public OnlineSubscription(String name,String address) throws Exception {
		super(name,address);
		if(address.contains("@")) {
			this.setRate(3);		
		}else {
			throw new Exception(address);
		}
	}
	public String toString() {
		return "Online "+super.toString();
	}
	
}
public class Exercise5 {
	public static void main(String[] args) {
		PhysicalSubscription ph1;
		try {
			ph1 = new PhysicalSubscription("Mikail", "Yasamal12");
			System.out.println(ph1.toString());
		} catch (Exception e) {
			e.printStackTrace();
		}
		OnlineSubscription onl1;
		try {
			onl1 = new OnlineSubscription("Aydin", "@Yasamal12");
			System.out.println(onl1.toString());
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("Let's check another 2 subscribers: ");
		try {
			PhysicalSubscription ph2 = new PhysicalSubscription("Seymur", "28May");
			System.out.println(ph2.toString());
		} catch (Exception e) {
			e.printStackTrace();
		}
		OnlineSubscription onl2;
		try {
			onl2 = new OnlineSubscription("Etibar", "Drujba@");
			System.out.println(onl2.toString());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
