package Exericse6;
class Element{
	private String symbol;
	private int atomnumber;
	private float atomweight;
	private MetalElement metal;
	private NonMetalElement nonmetal;
	public Element(String symbol, int atomnumber, float atomweight) {
		this.symbol = symbol;
		this.atomnumber = atomnumber;
		this.atomweight = atomweight;
	}
	public String getSymbol() {
		return symbol;
	}
	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}
	public float getAtomnumber() {
		return atomnumber;
	}
	public void setAtomnumber(int atomnumber) {
		this.atomnumber = atomnumber;
	}
	public float getAtomweight() {
		return atomweight;
	}
	public void setAtomweight(float atomweight) {
		this.atomweight = atomweight;
	}
	public NonMetalElement getNonmetal() {
		return nonmetal;
	}
	public void setNonmetal(NonMetalElement nonmetal) {
		this.nonmetal = nonmetal;
	}
	public String toString() {
		if(atomnumber==3 || atomnumber==4 || (atomnumber>=11 && atomnumber<=13) || (atomnumber>=19 && atomnumber<=31) || (atomnumber>=37 && atomnumber<=50) || (atomnumber>=55 && atomnumber<83) || (atomnumber>=87 && atomnumber<=116) ) {
			metal = new MetalElement();
			return "Metal Element: "+symbol+", atomic number: "+atomnumber+", atomic weight: "+atomweight+", properties :  "+ metal.toString();
		}else {
			nonmetal = new NonMetalElement();
			return "Non-Metal Element: "+symbol+", atomic number: "+atomnumber+", atomic weight: "+atomweight+", properties :  "+  nonmetal.toString();
		}
	}
}

class MetalElement{
	public String toString() {
		return "[good conductor, malleable as solid, hard, high melting points, high density]";
	}	
}

class NonMetalElement{
	public String toString() {
		return "[bad conductor, brittle, soft,ductile, high ionization energies, high electronegativities]";
	}	
}

public class Exercise6 {

	public static void main(String[] args) {
		System.out.println("Let's check Ferrum ( metal )");
		Element ferrum = new Element("Fe", 26, 56.659f);
		System.out.println(ferrum.toString());
		System.out.println("Let's check Sulfur ( non-metal )");
		Element sulfur = new Element("S", 16, 32.064f);
		System.out.println(sulfur.toString());
		System.out.println("Let's check Fluorine ( non-metal )");
		Element fluorine = new Element("F", 9, 18.95f);
		System.out.println(fluorine.toString());
		System.out.println("Scientists have found that atomic weigth of Fluorine now is 19, let's change.");
		fluorine.setAtomweight(19);
		System.out.println(fluorine.toString());
		System.out.println("Let's check now one more metal with big atomic number");
		Element moscovium = new Element("Mc", 115, 288);
		System.out.println(moscovium.toString());
		
	}

}
