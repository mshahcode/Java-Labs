package Exericse7;
import java.util.Arrays;
class Department{
	private String name;
	private Student student;
	private UniveristyCourse[] courses;
	public Department(String name,Student student,UniveristyCourse[] courses) {
		this.setCourses(courses);
		this.student = student;
		switch (name) {
		case "CS":
			this.name = "Computer Science";
			break;
		case "CHEM":
			this.name = "Chemistry";
			break;
		case "PHY":
			this.name = "Physics";
			break;
		default:
			System.out.println("Wrong name!");
		}
	}
	public String getName() {
		return name;
	}

	public void setName(String name) {
		switch (name) {
		case "CS":
			this.name = "Computer Science";
			break;
		case "CHEM":
			this.name = "Chemistry";
			break;
		case "PHY":
			this.name = "Physics";
			break;
		default:
			System.out.println("Wrong name!");
		}
	}
	public Student getStudent() {
		return student;
	}
	public void setStudent(Student student) {
		this.student = student;
	}
	public String toString() {
		String[] str = new String[courses.length];
		int i =0;
		for(i = 0;i< courses.length;i++) {
			str[i] = courses[i].getCoursename();;
		}
		return student.toString() +", Department : "+this.name+", Specific courses : "+ Arrays.toString(str);
	}
	public UniveristyCourse[] getCourses() {
		return courses;
	}
	public void setCourses(UniveristyCourse[] courses) {
		this.courses = courses;
	}
}
class University{
	private String name;
	private String city;
	private Department[] departments;
	public University(String name, String city,Department[] departments) {
		this.name = name;
		this.city = city;
		this.departments = departments;
	}
	public Department[] getDepartments() {
		return departments;
	}
	public void setDepartments(Department[] departments) {
		this.departments = departments;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String printUni() {
		String[] str = new String[departments.length];
		int i =0;
		for(i = 0;i< departments.length;i++) {
			str[i] = departments[i].getName();
		}
		return "University : "+name+", City : "+city+", Department :  "+Arrays.toString(str);
	}
}
class UniveristyCourse{
	private String coursename;
	private Department department;
	private int coursenum;
	private int numofcredit;
	
	private String level;
	public UniveristyCourse(String coursename,String level) {
		this.level = level;
		this.coursename = coursename;
	}
	public UniveristyCourse(String coursename, Department derpartment, int coursenum, int numofcredit,String level) {
		this.coursename = coursename;
		this.department = derpartment;
		this.coursenum = coursenum;
		this.numofcredit = numofcredit;
		this.setLevel(level);
	}
	public String getCoursename() {
		return coursename;
	}
	public void setCoursename(String coursename) {
		this.coursename = coursename;
	}
	public Department getDepartment() {
		return department;
	}
	public void setDepartment(Department department) {
		this.department = department;
	}
	public Department getDepartnemt() {
		return department;
	}

	public void setDepartnemt(Department departnemt) {
		this.department = departnemt;
	}

	public int getCoursenum() {
		return coursenum;
	}

	public void setCoursenum(int coursenum) {
		this.coursenum = coursenum;
	}

	public int getNumofcredit() {
		return numofcredit;
	}

	public void setNumofcredit(int numofcredit) {
		this.numofcredit = numofcredit;
	}
	

	public String toString(){
		return this.coursenum+" - "+this.coursename+" (department of "+ department.getName() +") / "+ this.numofcredit + " credits";
		
	}

	public String getLevel() {
		return level;
	}

	public void setLevel(String level) {
		this.level = level;
	}
}
class Student{
	private String fname;
	private String lname;
	private int studentnumber;
	private float annualtuition;
	public Student(String fname,String lname,int studentnumber) {
		this.fname = fname;
		this.lname = lname;
		this.studentnumber = studentnumber;
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public int getStudentnumber() {
		return studentnumber;
	}
	public void setStudentnumber(int studentnumber) {
		this.studentnumber = studentnumber;
	}
	public float getAnnualtuition() {
		return annualtuition;
	}
	public void setAnnualtuition(float annualtuition) {
		this.annualtuition = annualtuition;
	}
}
class UndergraduateStudent extends Student {
	public UndergraduateStudent(String fname, String lname, int studentnumber) {
		super(fname, lname, studentnumber);
		super.setAnnualtuition(2000);
	}
	public String toString() {
		return "UnderGraduate Student, name : "+super.getFname()+", Lastname : "+super.getLname()+", Student number : "+super.getStudentnumber()+", Annual tuition : "+super.getAnnualtuition(); 
	}
}
class GraduateStudent extends Student {
	public GraduateStudent(String fname, String lname, int studentnumber) {
		super(fname, lname, studentnumber);
		super.setAnnualtuition(3000);
	}
	public String toString() {
		return "Graduate Student, name : "+super.getFname()+", Lastname : "+super.getLname()+", Student number : "+super.getStudentnumber()+", Annual tuition : "+super.getAnnualtuition(); 
	}
}

public class Exercise7 {

	public static void main(String[] args) {
		Student undergrad = new UndergraduateStudent("Mika", "Shah", 12);
		UniveristyCourse[] undergraduatecourses = new UniveristyCourse[] {new UniveristyCourse("JAVA","UnderGraduate"),new UniveristyCourse("HTML","UnderGraduate"),new UniveristyCourse("CSS","UnderGraduate")};
		Department departnemt = new Department("CS",undergrad,undergraduatecourses);
		System.out.println(departnemt.toString());
		
		System.out.println("Same department, but now Graduate Student");
		Student graduate = new GraduateStudent("Aydin", "Shah", 13);
		UniveristyCourse[] graduatecourses = new UniveristyCourse[] {new UniveristyCourse("MachineLearining","Graduate"),new UniveristyCourse("AI","Graduate"),new UniveristyCourse("DataAnalysis","Graduate")};
		departnemt.setStudent(graduate);
		departnemt.setCourses(graduatecourses);
		System.out.println(departnemt.toString());
		
		System.out.println("Let's create UnderGraduate Student in Chemical Department");
		Student undergrad2 = new UndergraduateStudent("Seymur", "Mirzabayov", 14);
		UniveristyCourse[] undergraduatecourses2 = new UniveristyCourse[] {new UniveristyCourse("Bonds","UnderGraduate"),new UniveristyCourse("Reactions","UnderGraduate"),new UniveristyCourse("Periodic table","UnderGraduate")};
		departnemt.setName("CHEM");
		departnemt.setStudent(undergrad2);
		departnemt.setCourses(undergraduatecourses2);
		System.out.println(departnemt.toString());

		
		
	}

}
