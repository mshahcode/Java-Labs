package Exericse8;
import java.util.Arrays;
@SuppressWarnings("serial")
class UnvalidGradeException extends Exception{
	@SuppressWarnings("unused")
	private Object s;
	public UnvalidGradeException(char s) {
		this.s = s;
	}
	public String getMessage() {
		return "The grade should be : A , B , C, D, E, F";
	}
}
class Department{
	private String name;
	private Student student;
	private String[] grades;
	public Department(String name,Student student,String[] grades) {
		this.grades = grades;
		this.student = student;
		switch (name) {
		case "CS":
			this.name = "Computer Science";
			break;
		case "CHEM":
			this.name = "Chemistry";
			break;
		case "PHY":
			this.name = "Physics";
			break;
		default:
			System.out.println("Wrong name!");
		}
	}
	public String getName() {
		return name;
	}

	public void setName(String name) {
		switch (name) {
		case "CS":
			this.name = "Computer Science";
			break;
		case "CHEM":
			this.name = "Chemistry";
			break;
		case "PHY":
			this.name = "Physics";
			break;
		default:
			System.out.println("Wrong name!");
		}
	}
	public Student getStudent() {
		return student;
	}
	public void setStudent(Student student) {
		this.student = student;
	}
	public String toString() {
		return student.toString() +", Department : "+this.name+", Specific courses : "+ Arrays.toString(grades);
	}
	
}
class University{
	private String name;
	private String city;
	private Department[] departments;
	public University(String name, String city,Department[] departments) {
		this.name = name;
		this.city = city;
		this.departments = departments;
	}
	public Department[] getDepartments() {
		return departments;
	}
	public void setDepartments(Department[] departments) {
		this.departments = departments;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String printUni() {
		String[] str = new String[departments.length];
		int i =0;
		for(i = 0;i< departments.length;i++) {
			str[i] = departments[i].getName();
		}
		return "University : "+name+", City : "+city+", Department :  "+Arrays.toString(str);
	}
}
class UniveristyCourse{
	private String coursename;
	private Department department;
	private int coursenum;
	private int numofcredit;
	
	private String level;
	public UniveristyCourse(String coursename,String level) {
		this.level = level;
		this.coursename = coursename;
	}
	public UniveristyCourse(String coursename, Department derpartment, int coursenum, int numofcredit,String level) {
		this.coursename = coursename;
		this.department = derpartment;
		this.coursenum = coursenum;
		this.numofcredit = numofcredit;
		this.setLevel(level);
	}
	public String getCoursename() {
		return coursename;
	}
	public void setCoursename(String coursename) {
		this.coursename = coursename;
	}
	public Department getDepartment() {
		return department;
	}
	public void setDepartment(Department department) {
		this.department = department;
	}
	public Department getDepartnemt() {
		return department;
	}

	public void setDepartnemt(Department departnemt) {
		this.department = departnemt;
	}

	public int getCoursenum() {
		return coursenum;
	}

	public void setCoursenum(int coursenum) {
		this.coursenum = coursenum;
	}

	public int getNumofcredit() {
		return numofcredit;
	}

	public void setNumofcredit(int numofcredit) {
		this.numofcredit = numofcredit;
	}
	

	public String toString(){
		return this.coursenum+" - "+this.coursename+" (department of "+ department.getName() +") / "+ this.numofcredit + " credits";
		
	}

	public String getLevel() {
		return level;
	}

	public void setLevel(String level) {
		this.level = level;
	}
}
class Student{
	private String fname;
	private String lname;
	private int studentnumber;
	private float annualtuition;
	public Student(String fname,String lname,int studentnumber) {
		this.fname = fname;
		this.lname = lname;
		this.studentnumber = studentnumber;
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public int getStudentnumber() {
		return studentnumber;
	}
	public void setStudentnumber(int studentnumber) {
		this.studentnumber = studentnumber;
	}
	public float getAnnualtuition() {
		return annualtuition;
	}
	public void setAnnualtuition(float annualtuition) {
		this.annualtuition = annualtuition;
	}
}
class UndergraduateStudent extends Student {
	public UndergraduateStudent(String fname, String lname, int studentnumber) {
		super(fname, lname, studentnumber);
		super.setAnnualtuition(2000);
	}
	public String toString() {
		return "UnderGraduate Student, name : "+super.getFname()+", Lastname : "+super.getLname()+", Student number : "+super.getStudentnumber()+", Annual tuition : "+super.getAnnualtuition(); 
	}
}
class GraduateStudent extends Student {
	public GraduateStudent(String fname, String lname, int studentnumber) {
		super(fname, lname, studentnumber);
		super.setAnnualtuition(3000);
	}
	public String toString() {
		return "Graduate Student, name : "+super.getFname()+", Lastname : "+super.getLname()+", Student number : "+super.getStudentnumber()+", Annual tuition : "+super.getAnnualtuition(); 
	}
}

class Pair<F,S>{
	private F f;
	private S s;
	public Pair(F f, S s) throws UnvalidGradeException{
		if( (char) s != 'A' &&  (char) s != 'B' &&  (char) s != 'C' &&  (char) s != 'D' &&  (char) s != 'E' && (char) s != 'F') {
			throw new UnvalidGradeException((char) s);
		}
		this.f = f;
		this.s = s;
	}
	public F getF() {
		return f;
	}
	public void setF(F f) {
		this.f = f;
	}
	public S getS() {
		return s;
	}
	public void setS(S s) {
		this.s = s;
	}
	public String toString() {
		return this.f+" grade("+this.s+")";
	}
}
public class Exercise8 {

	public static void main(String[] args) {
		try {
			Pair<String, Character> grade1 = new Pair<String, Character>("JAVA", 'A');
			Pair<String, Character> grade2 = new Pair<String, Character>("HTML", 'B');
			Pair<String, Character> grade3 = new Pair<String, Character>("CSS", 'C');
			String[] grades = new String[] {grade1.toString(),grade2.toString(),grade3.toString()};
			Student undergrad = new UndergraduateStudent("Mika", "Shah", 12);
			Department departnemt = new Department("CS",undergrad,grades);
			System.out.println(departnemt.toString());
		} catch (UnvalidGradeException e) {
			e.printStackTrace();
		}
		
		try {
			Pair<String, Character> grade3 = new Pair<String, Character>("MachineLearining", 'F');
			Pair<String, Character> grade4 = new Pair<String, Character>("AI", 'E');
			Pair<String, Character> grade5 = new Pair<String, Character>("DataAnalysis", 'D');
			String[] grades2 = new String[] {grade3.toString(),grade4.toString(),grade5.toString()};
			Student grad = new GraduateStudent("Aydin", "Shah", 13);
			Department departnemt = new Department("CS",grad,grades2);
			System.out.println(departnemt.toString());
		} catch (UnvalidGradeException e) {
			e.printStackTrace();
		}
		System.out.println("Let's write for Chemical UnderGraduate Student");
		try {
			Pair<String, Character> grade6 = new Pair<String, Character>("Bonds", 'B');
			Pair<String, Character> grade7 = new Pair<String, Character>("Reactions", 'F');
			Pair<String, Character> grade8 = new Pair<String, Character>("Periodic table", 'A');
			String[] grades = new String[] {grade6.toString(),grade7.toString(),grade8.toString()};
			Student undergrad = new UndergraduateStudent("Seymur", "Mirzabayov", 14);
			Department departnemt = new Department("CHEM",undergrad,grades);
			System.out.println(departnemt.toString());
		} catch (UnvalidGradeException e) {
			e.printStackTrace();
		}
			
	}

}
