package exercise;
interface PlaneFigures{
	// all classes wil implement this methods
	float area();
	float perimeter();
}
class Triangle implements PlaneFigures{
	private float x;
	private float y;
	private float z;
	public Triangle(float x,float y,float z) {
		this.x= x;
		this.y = y;
		this.z = z;
	}
	public float area() {
		// i am finding area of triangle via formula of 3 sides (Geron)
		float area = (float) Math.sqrt(0.5*perimeter()*(0.5*perimeter()-x)*(0.5*perimeter()-y)*(0.5*perimeter()-z));
		return area;
	}

	@Override
	public float perimeter() {
		float perimeter = x+y+z;
		return perimeter;
	}	
}
class Rectangle implements PlaneFigures{
	float width;
	float height;
	public Rectangle(float width, float height) {
		this.width = width;
		this.height = height;
		// TODO Auto-generated constructor stub
	}

	@Override
	public float area() {
		return this.width*this.height;
	}

	@Override
	public float perimeter() {
		
		return 2*(this.width+this.height);
	}
	
}
class Point{
	float x;
	float y;
	public Point(float x,float y) {
		this.x = x;
		this.y = y;
	}
	
	public float getRadius() {
		return (float) Math.sqrt(x*x+y*y);
	}
}
class Circle implements PlaneFigures{
	Point p;
	// Aggreagation
	public Circle(Point p) {
		this.p = p;
	}
	

	@Override
	public float area() {
		return (float) (Math.PI*p.getRadius()*p.getRadius());
	}

	@Override
	public float perimeter() {
		return (float) (Math.PI)*2*p.getRadius();
	}
	
}
class Diagonal{
	float side;
	float angle;

	public Diagonal(float side,float angle) {
		//Composition
		this.side = side;
		this.angle = angle;
	}
	public float getDiagonal1() {
		// 1 diaganal
		return (float) (side*Math.sqrt(2+2*Math.cos(angle)));
	}
	public float getDiagonal2() {
		// 2 diaganal
		return (float) (side*Math.sqrt(2-2*Math.cos(angle)));
	}
}
class Rhombus implements PlaneFigures{
	Diagonal diagonal;
	public Rhombus(float side,float angle) {
		diagonal = new Diagonal(side, angle);
	}


	public float area() {
		// s = d1*d2/2
		float area = (diagonal.getDiagonal1()*diagonal.getDiagonal2())/2;
		return area;
	}

	@Override
	public float perimeter() {
		return 4*diagonal.side;
	}
	
}
public class Main {

	public static void main(String[] args) {
		PlaneFigures pf;
		
		pf = new Triangle(3.0f,4.0f,5.0f);
		System.out.println("Area(Triangle)="+pf.area());
		System.out.println("Perimeter(Triangle)= "+pf.perimeter());
		
		pf = new Rectangle(3.4f, 8.2f);
		System.out.println("Area(Rectangle)= "+pf.area());
		System.out.println("Perimeter(Rectangle)= "+pf.perimeter());
		
		Point point = new Point(5.6f, 4.8f);
		pf = new Circle(point);
		System.out.println("Area(Circle)= "+pf.area());
		System.out.println("Perimeter(Circle)= "+pf.perimeter());
		
		pf = new Rhombus(5.0f,(float)(2*Math.PI/3));
		System.out.println("Area(Rhombus)= "+pf.area());
		System.out.println("Perimeter(Rhombus)= "+pf.perimeter());

	}

}
